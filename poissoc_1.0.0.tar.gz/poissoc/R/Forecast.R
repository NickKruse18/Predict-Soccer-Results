
Chances = function(TStats,Games,teams){
  Chances = cbind(Games[,1],Games[,2],0,0)
  n = nrow(Games);  Games[1:(2*n)] = match(Games[1:(2*n)],teams)
  k = (length(TStats)-2)%/%2;  te = length(teams)
  p = TStats[2*k+2]+TStats[k+te*Games[,3]-te+Games[,2]]-TStats[Games[,1]+te*Games[,3]-te]-TStats[2*k+1]
  Chances[,3] = 1/(1+exp(p))
  p = TStats[2*k+2]+TStats[k+te*Games[,3]-te+Games[,1]]-TStats[Games[,2]+te*Games[,3]-te]+TStats[2*k+1]
  Chances[,4] = 1/(1+exp(p))
  return(Chances)
}

PredictGame = function(Game){
  R = numeric(3)
  H = dpois(0:7,90*Game[1])
  A = dpois(0:7,90*Game[2])
  R[2] = sum(H*A)
  for(j1 in 1:8){
    if(j1>1){ R[1] = R[1] + sum(H[j1]*A[1:(j1-1)]) }
    if(j1<8){ R[3] = R[3] + sum(H[j1]*A[(j1+1):8]) }
  }
  D = c(R,numeric(10));  i = 3
  for(i1 in 1:4){
    for(i2 in 1:(5-i1)){
      i = i + 1;  D[i] = H[i1]*A[i2]
    }
  }
  return(D/sum(R))
}

PredictGames = function(TStats,Games,Teams,startpoints=numeric(length(Teams[[2]])),m=10000){
  n = nrow(Games);  R = matrix(0,n,13);  teamids = Teams[[2]];  Games = as.matrix(Games[,3:5])
  C = Chances(TStats[,5],Games,teamids)
  for(i in 1:n){
    R[i,] = PredictGame(C[i,3:4])
  }
  R = cbind(Games[,1:2],R)
  colnames(R) = c("Home","Away","HomeWin","Draw","AwayWin","0-0","0-1","0-2","0-3","1-0","1-1","1-2","2-0","2-1","3-0")
  TT = R[,1:5];  k = length(teamids);  Rank = matrix(0,k,k);  P = startpoints
  for(i in 1:m){
    U = runif(n)
    H = (U<TT[,3]);  D = (U<TT[,3]+TT[,4])&(!H);  A = (!H)&(!D)
    for(I in 1:k){
      P[I] = startpoints[I] + 3*sum(H&(TT[,1]==teamids[I]))+sum(D&(TT[,1]==teamids[I]))+sum(D&(TT[,2]==teamids[I]))+3*sum(A&(TT[,2]==teamids[I]))
    }
    I = order(P,decreasing=T)+k*(1:k)-k
    Rank[I] = Rank[I] + 1
  }
  Rank = Rank/m
  rownames(Rank) = Teams[[1]];  pos = numeric(k)
  for(i in 1:k){
    if(i==11){ d = "th" } else if(i==12){ d = "th" } else if(i==13){ d = "th" }
    else if((i-1)%%10+1==1){ d = "st" } else if((i-1)%%10+1==2){ d = "nd" }
    else if((i-1)%%10+1==3){ d = "rd" } else{ d = "th" }
    pos[i] = paste0(i,d)
  }
  colnames(Rank) = pos;  R[,3:15] = 1/R[,3:15];  Rank[Rank==0] = Inf
  R = as.data.frame(R);  R$Home = Teams[[1]][match(R$Home,teamids)];  R$Away = Teams[[1]][match(R$Away,teamids)]
  return(list(GameOdds=R,FinalPlaceOdds = 1/Rank))
}


SetGames = function(Teams,full=T){
  Teamids = Teams[[2]];  Games = 0;  k = length(Teamids)
  if(full==T){
    Games = matrix(0,(k-1)*k,3);  i = 1
    for(i1 in 1:k){ for(i2 in 1:k){
      if(i1 == i2){ next }
      Games[i,] = c(Teamids[i1],Teamids[i2],1);  i = i + 1
    } } }
  else{
    Games = matrix(0,0,3)
    print("Type your desired matches type: 'w', when finished. To set a match between teams use the numbers seen below");  w = T
    for(i in 1:k){ print(paste0(Teams[[1]][i],": ",i)) };  a = 0
    print("First Match:")
    while(w){
      H = readline("Home: ");  if(H=="w"){ w = F;  break }
      A = readline("Away: ");  if(A=="w"){ w = F;  break }
      Games = rbind(Games,c(Teams[[2]][as.integer(H)],Teams[[2]][as.integer(A)],1))
      print("Next Match:");  a = a + 1
      if(a >= 10){ for(i in 1:k){ print(paste0(Teams[[1]][i],": ",i)) };  a = 0 }
    }
  }
  Games = cbind(0,0,Games);  colnames(Games) = c("Home","Away","HomeID","AwayID","Season")
  Games = as.data.frame(Games);  Games$Home = Teams[[1]][match(Games$HomeID,Teamids)];  Games$Away = Teams[[1]][match(Games$AwayID,Teamids)]
  return(Games)
}
