LikelihoodTeam = function(stats,Games,ses,te){
  n = nrow(Games);  k = te*ses;  l = -10*sum((stats[1:te])^2+(stats[k+1:te])^2)
  if(ses>1){ for(i in 1:te){ l = l - 10*sum(diff(stats[te*(1:ses)+i-te])^2 + diff(stats[k+te*(1:ses)+i-te])^2) } }
  p = 1/(1+exp(stats[2*k+2]+stats[k+te*Games[,5]-te+Games[,2]]-stats[Games[,1]+te*Games[,5]-te]-stats[2*k+1]))
  l = l + sum((Games[,3]*log(p) - 90*p))
  p = 1/(1+exp(stats[2*k+2]+stats[k+te*Games[,5]-te+Games[,1]]-stats[Games[,2]+te*Games[,5]-te]+stats[2*k+1]))
  l = l + sum((Games[,4]*log(p) - 90*p))
  return(-l)
}

FitTeams = function(Games,Teams){
  Games = as.matrix(Games[,3:8])
  Teamids = Teams[[2]]
  n = nrow(Games);  Games[1:(2*n)] = match(Games[1:(2*n)],Teamids);  ses = max(Games[,5]);  te = length(Teamids)
  O = Inf;  W = T
  TStats = cbind(Teamids,(1:(2*te*ses)-1)%/%(te*ses)+1,((1:(2*te*ses)-1)%/%te)%%ses+1,0)
  TStats = rbind(TStats,c(0,0,0,0),c(0,0,0,0))
  while(W){
    Opt = optim(TStats[,4], LikelihoodTeam, Games = Games, ses = ses, te = te, method ="BFGS")
    TStats[,4] = Opt$par
    if(O-0.01<=Opt$value){ W = F }
    O = Opt$value
  }
  TStats = cbind(0,TStats)
  colnames(TStats) = c("Team","TeamID","Off/Def",colnames(Games)[5],"Strength")
  rownames(TStats) = NULL
  TStats = as.data.frame(TStats)
  TStats$Team = c(Teams[[1]][match(TStats$TeamID[1:(2*te*ses)],Teamids)],"HomeAdvantage","Average")
  return(TStats)
}


