
RetrieveH2H = function(Teams,start,end){
  TeamID = Teams[[2]]
  url = "https://www.soccerbase.com/teams/team.sd?";  n = length(TeamID)
  Games = matrix(0,0,6)
  for(i in 1:(n-1)){
    for(j in (i+1):n){
      download.file(url=paste0(url,"team_id=",TeamID[i],"&team2_id=",TeamID[j],"&teamTabs=h2h"),"D.txt")
      suppressWarnings({ fil = paste(readLines("D.txt"), collapse="\n") })

      Matches = unlist(gregexpr("Show full match details",fil))
      I1 = unlist(gregexpr(paste0("team_id=",TeamID[i]),fil))
      I2 = unlist(gregexpr(paste0("team_id=",TeamID[j]),fil))
      Score = unlist(gregexpr("</em>&nbsp;-&nbsp;<em>",fil))
      MatchID = unlist(gregexpr('id="tth2hg',fil))
      SeasonEnd = unlist(gregexpr('class="headlineBlock"',fil))
      Season = numeric()
      for(k in end:start){
        Season[end-k+1] = unlist(gregexpr(paste0(k,"/",k+1),fil))[1]
      }
      games = matrix(0,0,6)
      for(k in 1:length(Season)){
        if(Season[k] == -1){ next }
        h = SeasonEnd[SeasonEnd>Season[k]][1]
        Match = Matches[(Matches>Season[k])&(Matches<h)]
        for(k2 in Match){
          g = numeric(6);  i1 = I1[I1>k2][1];  i2 = I2[I2>k2][1]
          if(i1<i2){ g[1] = TeamID[i];  g[2] = TeamID[j] }
          else{ g[1] = TeamID[j];  g[2] = TeamID[i] }
          sH = Score[Score>k2][1];  d = sH-1
          while(substr(fil,d,d)!='>'){ d = d - 1 }
          g[3] = as.integer(substr(fil,d+1,sH-1))
          sA = Score[Score>k2][1]+21;  d = sA+1
          while(substr(fil,d,d)!='<'){ d = d + 1 }
          g[4] = as.integer(substr(fil,sA+1,d-1))
          MID = MatchID[match(T,MatchID>k2)-1]+9;  d = MID+1
          while(substr(fil,d,d)!='"'){ d = d + 1 }
          g[6] = as.integer(substr(fil,MID+1,d-1))

          g[5] = k

          games = rbind(games,c(g[1:6]))
        }
      }
      print(paste0(nrow(games)," matches between ", Teams[[1]][i]," & ",Teams[[1]][j],"."))
      Games = rbind(Games,games)
    }
  }
  Games = cbind(0,0,Games)
  colnames(Games) = c("Home","Away","HomeID","AwayID","Home Goals","Away Goals",paste0("Seasons since ",end),"MatchID")
  Games = as.data.frame(Games);  Games$Home = Teams[[1]][match(Games$HomeID,TeamID)];  Games$Away = Teams[[1]][match(Games$AwayID,TeamID)]
  return(Games)
}

RetrieveLeague = function(TourID){
  url = "https://www.soccerbase.com/tournaments/tournament.sd?tourn_id="

  download.file(url=paste0(url,TourID),"D.txt")
  suppressWarnings({ fil = paste(readLines("D.txt"), collapse="\n") })

  TID = unlist(gregexpr("team_id=",fil))+8
  Name = unlist(gregexpr("eam page",fil))+10
  teams = c()
  names = c()
  for(i in TID){
    sT = i;  d = sT
    while(substr(fil,d,d)!='"'){ d = d + 1 }
    ID = as.integer(substr(fil,sT,d-1))
    if(ID %in% teams){ next }
    sT = Name[Name>i][1];  d = sT
    while(substr(fil,d,d)!='<'){ d = d + 1 }
    name = substr(fil,sT,d-1)
    names = c(names,name)
    teams = c(teams,ID)
  }
  return(list(Names=names[order(teams)],IDs=teams[order(teams)]))
}




SetupLeague = function(){
  IDs = c();  names = c();  w = T
  print("This function will setup which teams should be considered. To find the ID of a team go to: https://www.soccerbase.com/teams/home.sd and find and click
        on a desired team. When at their page in their URL, the number after 'team_id=' is the team's ID.")
  print("When Finished type: 'w'")
  while(w){
    D = readline("Name: ")
    if(D == "w"){ w = F;  break }
    E = readline("ID: ")
    if(E == "w"){ w = F;  break }
    names = c(names,D)
    IDs = c(IDs,as.integer(E))
  }
  return(list(Names=names[order(IDs)],IDs=IDs[order(IDs)]))
}




